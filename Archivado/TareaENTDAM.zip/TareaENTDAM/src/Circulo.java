
public class Circulo implements Figura {
    String nombre;
    int radio;
    public Circulo(String nombre, int radio) {
        this.nombre = nombre;
        this.radio = radio;
    }

    public int getRadio() {
        return radio;
    }

    public String getNombre() {
        return nombre;
    }//Fin getNombre

    public void setRadio(int radio) {
        this.radio = radio;
    }//Fin setRadio
    @Override
    public int area() {
        return (int) (Math.PI*(radio * radio));
    }//Fin de area

    @Override
    public int perimetro() {
        return (int) (Math.PI*radio+radio);
    }//Fin perimetro

    @Override
    public void duplica() {
        if(radio>1000){
            throw new IllegalArgumentException("No se puede duplicar más");
        }else {
            radio = radio * 2;
        }
    }

    @Override
    public void divide2() {
        if(radio>0){
            radio=radio/2;
        }else{
            throw new IllegalArgumentException("Division imposible");
        }
    }
}
