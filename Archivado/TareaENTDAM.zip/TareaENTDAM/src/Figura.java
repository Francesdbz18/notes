
public interface Figura {
    int area();
    int perimetro();
    void duplica();
    void divide2();
}
