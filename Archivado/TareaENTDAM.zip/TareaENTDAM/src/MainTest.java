import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    public void testCargarArchivo_ArchivoNoExiste() {
        Main.fileName = "archivo_inexistente.csv";
        Main.cargarArchivo();
        assertEquals(2, Main.figuras.size());
    }

    @Test
    public void testCargarArchivo_ArchivoExiste() {
        Main.fileName =".\\src\\figuras.csv";
        Main.cargarArchivo();
        assertEquals(4, Main.figuras.size());
    }

    @Test
    public void testDividir2Radio0() {
        Main.figuras.add(new Circulo("Círculo", 0));
        Main.divide2();
        assertEquals(1, Main.figuras.size(), "La lista de figuras debe contener una figura");
        assertTrue(Main.figuras.get(0) instanceof Circulo, "La figura debe ser un círculo");
        assertEquals(0, ((Circulo) Main.figuras.get(0)).getRadio(), "El radio del círculo debe seguir siendo 0");
    }

    @Test
    public void testDivide2_CirculoRadio999() {
        ArrayList<Figura> misFiguras = new ArrayList<>();
        misFiguras.add(new Circulo("Circulo", 999));
        Main.figuras = misFiguras;
        Main.divide2();
        assertEquals(499, ((Circulo) Main.figuras.get(0)).getRadio());
    }

    @Test
    public void testMenu_OpcionInvalida() {
        String input = "5\n0\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        Main.menu();
    }

    @Test
    public void testCrearFigura_TipoDesconocido() {
        String[] parts = {"Rombo", "3"};
        Main.crearFigura(parts);
        assertEquals(1, Main.figuras.size());
    }

    @Test
    public void testcrearFigura_TipoConocido() {
        String[] parts = {"Círculo", "6"};
        Main.crearFigura(parts);
        assertEquals(2, Main.figuras.size());
    }
}