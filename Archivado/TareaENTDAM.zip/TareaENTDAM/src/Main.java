import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    static ArrayList<Figura> figuras = new ArrayList<>();
    static String fileName = ".\\src\\figuras.csv";
    public static void menu() {
        int opcion;
        Scanner scanner = new Scanner(System.in);
        boolean repetir = false;
        do {
            try {
                System.out.println("1. Calcular área \n2. Calcular perímetro\n3. Duplica\n4. Divide2\n0. Salir");
                opcion = scanner.nextInt();
                scanner.nextLine();
                switch (opcion) {
                    case 1:
                        area();
                        break;
                    case 2:
                        perimetro();
                        break;
                    case 3:
                        duplica();
                        break;
                    case 4:
                        divide2();
                        break;
                    case 0:
                        System.out.println("Saliendo...");
                        break;
                    default:
                        System.out.println("Error");
                        break;
                }
            }catch (InputMismatchException e){
                System.err.println("Opción no válida. Inténtelo de nuevo.");
                scanner.nextLine();
                repetir = true;
            }catch (Exception e){
                System.err.println("Error");
                scanner.nextLine();
                repetir = true;
            }
        } while (repetir);
    }

    public static void divide2() {
        if (!figuras.isEmpty()) {
            for (Figura figura : figuras) {
                try {
                    if (figura instanceof Circulo circulo4) {
                        circulo4.divide2();
                        System.out.println("Figura " + circulo4.nombre + " Valor del radio: " + circulo4.radio);
                    } else if (figura instanceof Cuadrado cuadrado4) {
                        cuadrado4.divide2();
                        System.out.println("Figura " + cuadrado4.nombre + " Valor del Lado: " + cuadrado4.lado);
                    } else if (figura instanceof Rectangulo rectangulo4) {
                        rectangulo4.divide2();
                        System.out.println("Figura " + rectangulo4.nombre + " Valor de la altura: " + rectangulo4.altura + " Valor de la base: " + rectangulo4.base);
                    } else {
                        System.out.println("No existe esta figura");
                    }
                }catch (IllegalArgumentException e){
                    System.err.println(e.getMessage());
                }
            }
        } else {
            System.out.println("La lista de figuras está vacía.");
        }
    }

    public static void duplica() {
        if (!figuras.isEmpty()) {
            for (Figura figura : figuras) {
                try {
                    if (figura instanceof Circulo circulo3) {
                        circulo3.duplica();
                        System.out.println("Figura: " + circulo3.nombre + " Radio: " + circulo3.radio);
                    } else if (figura instanceof Cuadrado cuadrado3) {
                        cuadrado3.duplica();
                        System.out.println("Figura: " + cuadrado3.nombre + " Lado: " + cuadrado3.lado);
                    } else if (figura instanceof Rectangulo rectangulo3) {
                        rectangulo3.duplica();
                        System.out.println("Figura: " + rectangulo3.nombre + " Altura: " + rectangulo3.altura  + " Base: " + rectangulo3.base);

                    } else {
                        System.out.println("La figura no existe.");
                    }
                }catch (IllegalArgumentException e){
                    System.err.println(e.getMessage());
                }
            }
        } else {
            System.out.println("La lista está vacía.");
        }
    }

    public static void perimetro() {
        if (!figuras.isEmpty()) {
            for (Figura figura : figuras) {
                if (figura instanceof Circulo circulo2) {
                    int perimetroCi = circulo2.perimetro();
                    System.out.println("Figura: "+circulo2.nombre+" El perimetro es: " + perimetroCi);
                } else if (figura instanceof Cuadrado cuadrado2) {
                    int perimetroCu= cuadrado2.perimetro();
                    System.out.println("Figura: "+ cuadrado2.nombre+" El perimetro del cuadrado es: " + perimetroCu);
                } else if (figura instanceof Rectangulo rectangulo2) {
                    int perimetroR = rectangulo2.perimetro();
                    System.out.println("Figura: "+rectangulo2.nombre+" El perimetro es: " +perimetroR);
                } else {
                    System.out.println("La figura no existe.");
                }
            }
        } else {
            System.out.println("La lista está vacía.");
        }
    }

    public static void area() {
        if (!figuras.isEmpty()) {
            for (Figura figura : figuras) {
                if (figura instanceof Circulo circulo1) {
                    int areaCi = circulo1.area();
                    System.out.println("Figura: "+circulo1.nombre+" El área del círculo es: " + areaCi);
                } else if (figura instanceof Cuadrado cuadrado1) {
                    int  areaCu = cuadrado1.area();
                    System.out.println("Figura: "+ cuadrado1.nombre+" El área del cuadrado es: " + areaCu);
                } else if (figura instanceof Rectangulo rectangulo1) {
                    int areaR = rectangulo1.area();
                    System.out.println("Figura: "+rectangulo1.nombre+" El área del rectángulo es: " + areaR);
                } else {
                    System.out.println("La figura no existe.");
                }
            }
        } else {
            System.out.println("La lista está vacía.");
        }
    }

    public static void cargarArchivo() {

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length > 0) {
                    crearFigura(parts);
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo");
        }
    }

    public static void crearFigura(String[] parts) {
        String figura = parts[0];
        switch (figura) {
            case "Círculo":
                int radio = Integer.parseInt(parts[1]);
                figuras.add(new Circulo(figura,radio));
                break;
            case "Cuadrado":
                int lado = Integer.parseInt(parts[1]);
                figuras.add(new Cuadrado(figura,lado));
                break;
            case "Rectángulo":
                int base = Integer.parseInt(parts[1]);
                int altura = Integer.parseInt(parts[2]);
                figuras.add(new Rectangulo(figura,base, altura));
                break;
            default:
                System.out.println("No se crea objeto. Tipo desconocido");
                break;
        }
    }

    public static void main(String[] args) {
        cargarArchivo();
        menu();
    }
}